import 'package:audioplayers/audioplayers.dart';

/// مشغّل مؤثرات صوتية بسيط. ضع ملفات mp3 داخل assets/audio/
/// بنفس الأسماء التالية، أو عدّل المسارات حسب ملفاتك الخاصة.
class AudioService {
  AudioService._();
  static final AudioService instance = AudioService._();

  final AudioPlayer _player = AudioPlayer();
  bool soundEnabled = true;

  Future<void> playCorrect() => _play('correct.mp3');
  Future<void> playWrong() => _play('wrong.mp3');
  Future<void> playWin() => _play('win.mp3');
  Future<void> playTap() => _play('tap.mp3');

  Future<void> _play(String fileName) async {
    if (!soundEnabled) return;
    try {
      await _player.play(AssetSource('audio/$fileName'));
    } catch (_) {
      // إن لم يوجد الملف الصوتي، نتجاهل الخطأ بصمت حتى لا يتعطل التطبيق
    }
  }
}
