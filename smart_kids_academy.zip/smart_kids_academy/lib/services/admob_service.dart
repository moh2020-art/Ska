import 'package:google_mobile_ads/google_mobile_ads.dart';

/// خدمة مركزية لإدارة كل إعلانات AdMob في التطبيق.
///
/// ⚠️ مهم جدًا قبل النشر:
/// المعرّفات (Ad Unit IDs) أدناه هي معرّفات AdMob التجريبية الرسمية من Google
/// (Test IDs) وتعمل فقط أثناء التطوير. يجب استبدالها بمعرّفاتك الحقيقية
/// من حساب AdMob الخاص بك قبل رفع التطبيق على المتجر، وإلا فلن تُحتسب
/// أي أرباح، وقد يُعلّق حسابك إن استخدمت معرّفات حقيقية مع نقرات وهمية
/// أثناء الاختبار.
class AdMobService {
  AdMobService._();
  static final AdMobService instance = AdMobService._();

  static Future<void> initialize() async {
    await MobileAds.instance.initialize();
    // إلزامي لتطبيقات الأطفال: يخبر AdMob أن يفلتر الإعلانات لتكون مناسبة للأطفال فقط.
    // يجب أيضًا تفعيل هذا الخيار من لوحة تحكم AdMob → App settings → Tagged for child-directed treatment.
    await MobileAds.instance.updateRequestConfiguration(
      RequestConfiguration(
        tagForChildDirectedTreatment: TagForChildDirectedTreatment.yes,
        maxAdContentRating: MaxAdContentRating.g,
      ),
    );
  }

  // ------------------- معرّفات الإعلانات (حقيقية - جاهزة للنشر) -------------------
  String get bannerAdUnitId => 'ca-app-pub-7099926009548964/5529508900';

  String get interstitialAdUnitId => 'ca-app-pub-7099926009548964/1699064785';

  String get rewardedAdUnitId => 'ca-app-pub-7099926009548964/3982447342';

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  int _levelsCompletedSinceLastAd = 0;

  /// اعرض إعلان بيني بعد كل مرحلتين مكتملتين (زيادة تكرار الإعلانات بناءً على الطلب)
  static const int levelsPerInterstitial = 2;

  BannerAd createBannerAd({required void Function() onFailed}) {
    return BannerAd(
      adUnitId: bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          onFailed();
        },
      ),
    )..load();
  }

  void loadInterstitial() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (_) => _interstitialAd = null,
      ),
    );
  }

  /// يُستدعى عند إنهاء كل مرحلة؛ يعرض إعلانًا بينيًا كل [levelsPerInterstitial] مراحل
  void onLevelCompleted({required void Function() onAdClosed}) {
    _levelsCompletedSinceLastAd++;
    if (_levelsCompletedSinceLastAd >= levelsPerInterstitial && _interstitialAd != null) {
      _levelsCompletedSinceLastAd = 0;
      _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          ad.dispose();
          loadInterstitial(); // تحميل مسبق للإعلان التالي
          onAdClosed();
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          ad.dispose();
          loadInterstitial();
          onAdClosed();
        },
      );
      _interstitialAd!.show();
      _interstitialAd = null;
    } else {
      onAdClosed();
    }
  }

  void loadRewardedAd({required void Function(bool available) onLoaded}) {
    RewardedAd.load(
      adUnitId: rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          onLoaded(true);
        },
        onAdFailedToLoad: (_) {
          _rewardedAd = null;
          onLoaded(false);
        },
      ),
    );
  }

  /// إعلان مكافأة اختياري (مثلًا: احصل على تلميح إضافي أو نجمة إضافية)
  void showRewardedAd({required void Function() onReward}) {
    if (_rewardedAd == null) return;
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
      },
    );
    _rewardedAd!.show(onUserEarnedReward: (ad, reward) => onReward());
  }
}
