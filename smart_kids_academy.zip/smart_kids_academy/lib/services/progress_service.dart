import 'package:shared_preferences/shared_preferences.dart';

/// يحفظ تقدم الطفل محليًا على الجهاز (بدون الحاجة لإنترنت أو حساب).
/// لكل فئة نحفظ: عدد النجوم لكل مرحلة، وأعلى مرحلة تم فتحها.
class ProgressService {
  ProgressService._();
  static final ProgressService instance = ProgressService._();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  String _starsKey(String categoryId, int levelNumber) =>
      'stars_${categoryId}_$levelNumber';

  String _unlockedKey(String categoryId) => 'unlocked_$categoryId';

  /// عدد النجوم المحفوظة لمرحلة معينة (0 إن لم تُلعب بعد)
  int getStars(String categoryId, int levelNumber) {
    return _prefs?.getInt(_starsKey(categoryId, levelNumber)) ?? 0;
  }

  /// يحفظ عدد النجوم فقط إذا كانت أعلى من المحفوظة سابقًا
  Future<void> saveStars(String categoryId, int levelNumber, int stars) async {
    final current = getStars(categoryId, levelNumber);
    if (stars > current) {
      await _prefs?.setInt(_starsKey(categoryId, levelNumber), stars);
    }
    // فتح المرحلة التالية تلقائيًا
    final unlocked = getUnlockedLevel(categoryId);
    if (levelNumber + 1 > unlocked) {
      await _prefs?.setInt(_unlockedKey(categoryId), levelNumber + 1);
    }
  }

  /// أعلى رقم مرحلة مسموح باللعب فيه (المرحلة 1 مفتوحة دائمًا)
  int getUnlockedLevel(String categoryId) {
    return _prefs?.getInt(_unlockedKey(categoryId)) ?? 1;
  }

  /// إجمالي النجوم في فئة كاملة (يُستخدم لعرض التقدم الإجمالي)
  int totalStarsForCategory(String categoryId, int levelCount) {
    int total = 0;
    for (var i = 1; i <= levelCount; i++) {
      total += getStars(categoryId, i);
    }
    return total;
  }

  /// إعادة تعيين كل التقدم (خيار في الإعدادات لأولياء الأمور)
  Future<void> resetAll() async {
    await _prefs?.clear();
  }
}
