import 'package:flutter/material.dart';
import 'star_rating.dart';

class LevelButton extends StatelessWidget {
  final int levelNumber;
  final bool isUnlocked;
  final int stars;
  final Color color;
  final VoidCallback onTap;

  const LevelButton({
    super.key,
    required this.levelNumber,
    required this.isUnlocked,
    required this.stars,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isUnlocked ? onTap : null,
      child: Opacity(
        opacity: isUnlocked ? 1.0 : 0.45,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: isUnlocked ? color : Colors.grey,
                shape: BoxShape.circle,
                boxShadow: isUnlocked
                    ? [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 4))]
                    : [],
              ),
              child: Center(
                child: isUnlocked
                    ? Text(
                        '$levelNumber',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      )
                    : const Icon(Icons.lock, color: Colors.white70, size: 24),
              ),
            ),
            const SizedBox(height: 4),
            if (isUnlocked) StarRating(stars: stars, size: 12),
          ],
        ),
      ),
    );
  }
}
