import 'package:flutter/material.dart';

class StarRating extends StatelessWidget {
  final int stars; // 0-3
  final double size;

  const StarRating({super.key, required this.stars, this.size = 20});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        return Icon(
          i < stars ? Icons.star_rounded : Icons.star_border_rounded,
          color: i < stars ? const Color(0xFFFFC107) : Colors.grey.shade400,
          size: size,
        );
      }),
    );
  }
}
