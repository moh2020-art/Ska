import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:confetti/confetti.dart';
import '../models/category_model.dart';
import '../models/level_model.dart';
import '../data/level_generator.dart';
import '../services/progress_service.dart';
import 'games/quiz_game_screen.dart';
import 'games/matching_game_screen.dart';
import 'games/sequence_game_screen.dart';
import 'games/balloon_pop_game_screen.dart';
import '../services/admob_service.dart';
import '../widgets/ad_banner_widget.dart';

class ResultsScreen extends StatefulWidget {
  final CategoryModel category;
  final LevelModel level;
  final int stars;
  final int correctAnswers;
  final int totalQuestions;

  const ResultsScreen({
    super.key,
    required this.category,
    required this.level,
    required this.stars,
    required this.correctAnswers,
    required this.totalQuestions,
  });

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  late ConfettiController _confettiController;
  late int currentStars;
  bool rewardedAdReady = false;
  bool rewardClaimed = false;

  @override
  void initState() {
    super.initState();
    currentStars = widget.stars;
    _confettiController = ConfettiController(duration: const Duration(seconds: 2));
    if (widget.stars >= 2) _confettiController.play();

    // تحميل إعلان مكافأة مسبقًا: يمنح نجمة إضافية للطفل مقابل مشاهدته (مساحة إعلانية اختيارية)
    if (widget.stars < 3) {
      AdMobService.instance.loadRewardedAd(onLoaded: (available) {
        if (mounted) setState(() => rewardedAdReady = available);
      });
    }
  }

  void _watchAdForExtraStar() {
    AdMobService.instance.showRewardedAd(onReward: () async {
      await ProgressService.instance.saveStars(widget.category.id, widget.level.levelNumber, currentStars + 1);
      if (mounted) {
        setState(() {
          currentStars = (currentStars + 1).clamp(0, 3);
          rewardClaimed = true;
          rewardedAdReady = false;
        });
        _confettiController.play();
      }
    });
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  void _goToNextLevel() {
    final nextLevelNumber = widget.level.levelNumber + 1;
    if (nextLevelNumber > widget.category.levelCount) {
      Navigator.pop(context); // انتهت كل مراحل الفئة
      return;
    }
    final difficulty = LevelGenerator.difficultyForLevel(nextLevelNumber, widget.category.levelCount);
    final nextLevel = LevelGenerator.generateSingleLevel(widget.category, nextLevelNumber, difficulty);

    Widget screen;
    switch (nextLevel.gameType) {
      case GameType.matching:
        screen = MatchingGameScreen(category: widget.category, level: nextLevel);
        break;
      case GameType.sequence:
      case GameType.fastPuzzle:
        screen = SequenceGameScreen(category: widget.category, level: nextLevel);
        break;
      case GameType.balloonPop:
        screen = BalloonPopGameScreen(category: widget.category, level: nextLevel);
        break;
      default:
        screen = QuizGameScreen(category: widget.category, level: nextLevel);
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final isLastLevel = widget.level.levelNumber >= widget.category.levelCount;
    final message = currentStars == 3
        ? 'ممتاز! أداء رائع 🌟'
        : currentStars == 2
            ? 'أحسنت! يمكنك الحصول على المزيد 👏'
            : currentStars == 1
                ? 'جيد! حاول مرة أخرى لتحصل على نجوم أكثر'
                : 'حاول مرة أخرى، أنت تستطيع! 💪';

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🎉', style: TextStyle(fontSize: 72))
                            .animate()
                            .scale(duration: 500.ms, curve: Curves.elasticOut),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(3, (i) {
                            return Icon(
                              i < currentStars ? Icons.star_rounded : Icons.star_border_rounded,
                              color: i < currentStars ? const Color(0xFFFFC107) : Colors.grey.shade400,
                              size: 48,
                            )
                                .animate()
                                .fadeIn(delay: (200 * i).ms, duration: 300.ms)
                                .scale(delay: (200 * i).ms, duration: 300.ms, curve: Curves.elasticOut);
                          }),
                        ),
                        const SizedBox(height: 24),
                        Text(message, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(
                          '${widget.correctAnswers} من ${widget.totalQuestions} إجابات صحيحة',
                          style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                        ),
                        if (currentStars < 3 && rewardedAdReady && !rewardClaimed) ...[
                          const SizedBox(height: 20),
                          ElevatedButton.icon(
                            onPressed: _watchAdForExtraStar,
                            icon: const Icon(Icons.play_circle_fill),
                            label: const Text('شاهد إعلانًا واحصل على نجمة إضافية'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFFC107),
                              foregroundColor: Colors.black87,
                            ),
                          ).animate().fadeIn(delay: 700.ms),
                        ],
                        const SizedBox(height: 32),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            OutlinedButton.icon(
                              onPressed: () => Navigator.pop(context),
                              icon: const Icon(Icons.map_outlined),
                              label: const Text('خريطة المراحل'),
                            ),
                            const SizedBox(width: 16),
                            if (!isLastLevel)
                              ElevatedButton.icon(
                                onPressed: _goToNextLevel,
                                icon: const Icon(Icons.arrow_forward),
                                label: const Text('المرحلة التالية'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: widget.category.color,
                                  foregroundColor: Colors.white,
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                ConfettiWidget(
                  confettiController: _confettiController,
                  blastDirectionality: BlastDirectionality.explosive,
                  shouldLoop: false,
                  numberOfParticles: 30,
                ),
              ],
            ),
          ),
          const AdBannerWidget(),
        ],
      ),
    );
  }
}
