import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/category_model.dart';
import '../data/categories_data.dart';
import '../services/progress_service.dart';
import '../widgets/ad_banner_widget.dart';
import 'level_map_screen.dart';

class AgeSectionScreen extends StatelessWidget {
  final AgeGroup ageGroup;
  const AgeSectionScreen({super.key, required this.ageGroup});

  @override
  Widget build(BuildContext context) {
    final categories = CategoriesData.byAgeGroup(ageGroup);

    return Scaffold(
      appBar: AppBar(title: Text(ageGroup.nameAr)),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.95,
              ),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final category = categories[index];
                final earnedStars = ProgressService.instance
                    .totalStarsForCategory(category.id, category.levelCount);
                final maxStars = category.levelCount * 3;

                return Material(
                  color: category.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => LevelMapScreen(category: category)),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(category.icon, size: 48, color: category.color),
                          const SizedBox(height: 12),
                          Text(
                            category.nameAr,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${category.levelCount} مرحلة',
                            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.star_rounded, color: Color(0xFFFFC107), size: 16),
                              const SizedBox(width: 4),
                              Text('$earnedStars / $maxStars', style: const TextStyle(fontSize: 12)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                )
                    .animate()
                    .fadeIn(delay: (80 * index).ms, duration: 350.ms)
                    .scale(begin: const Offset(0.85, 0.85), end: const Offset(1, 1), delay: (80 * index).ms, duration: 350.ms);
              },
            ),
          ),
          const AdBannerWidget(),
        ],
      ),
    );
  }
}
