import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/category_model.dart';
import '../models/level_model.dart';
import '../data/level_generator.dart';
import '../services/progress_service.dart';
import '../widgets/level_button.dart';
import '../widgets/ad_banner_widget.dart';
import 'games/quiz_game_screen.dart';
import 'games/matching_game_screen.dart';
import 'games/sequence_game_screen.dart';
import 'games/balloon_pop_game_screen.dart';

class LevelMapScreen extends StatefulWidget {
  final CategoryModel category;
  const LevelMapScreen({super.key, required this.category});

  @override
  State<LevelMapScreen> createState() => _LevelMapScreenState();
}

class _LevelMapScreenState extends State<LevelMapScreen> {
  late int unlockedLevel;

  @override
  void initState() {
    super.initState();
    unlockedLevel = ProgressService.instance.getUnlockedLevel(widget.category.id);
  }

  void _openLevel(int levelNumber) async {
    final difficulty = LevelGenerator.difficultyForLevel(levelNumber, widget.category.levelCount);
    final level = LevelGenerator.generateSingleLevel(widget.category, levelNumber, difficulty);

    Widget screen;
    switch (level.gameType) {
      case GameType.matching:
        screen = MatchingGameScreen(category: widget.category, level: level);
        break;
      case GameType.sequence:
      case GameType.fastPuzzle:
        screen = SequenceGameScreen(category: widget.category, level: level);
        break;
      case GameType.balloonPop:
        screen = BalloonPopGameScreen(category: widget.category, level: level);
        break;
      case GameType.quiz:
      case GameType.counting:
      case GameType.math:
      case GameType.trueFalse:
        screen = QuizGameScreen(category: widget.category, level: level);
        break;
    }

    await Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
    setState(() {
      unlockedLevel = ProgressService.instance.getUnlockedLevel(widget.category.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.category.nameAr)),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: 16,
                crossAxisSpacing: 12,
              ),
              itemCount: widget.category.levelCount,
              itemBuilder: (context, index) {
                final levelNumber = index + 1;
                final isUnlocked = levelNumber <= unlockedLevel;
                final stars = ProgressService.instance.getStars(widget.category.id, levelNumber);
                return LevelButton(
                  levelNumber: levelNumber,
                  isUnlocked: isUnlocked,
                  stars: stars,
                  color: widget.category.color,
                  onTap: () => _openLevel(levelNumber),
                )
                    .animate()
                    .fadeIn(delay: (25 * (index % 20)).ms, duration: 250.ms)
                    .scale(begin: const Offset(0.6, 0.6), end: const Offset(1, 1), delay: (25 * (index % 20)).ms, duration: 250.ms);
              },
            ),
          ),
          const AdBannerWidget(),
        ],
      ),
    );
  }
}
