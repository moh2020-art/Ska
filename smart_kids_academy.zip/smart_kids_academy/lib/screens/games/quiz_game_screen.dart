import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../../models/category_model.dart';
import '../../models/level_model.dart';
import '../../services/admob_service.dart';
import '../../services/audio_service.dart';
import '../../services/progress_service.dart';
import '../results_screen.dart';

class QuizGameScreen extends StatefulWidget {
  final CategoryModel category;
  final LevelModel level;
  const QuizGameScreen({super.key, required this.category, required this.level});

  @override
  State<QuizGameScreen> createState() => _QuizGameScreenState();
}

class _QuizGameScreenState extends State<QuizGameScreen> {
  int currentQuestion = 0;
  int correctAnswers = 0;
  int? selectedIndex;
  bool answered = false;
  bool? lastAnswerCorrect;
  BannerAd? _bannerAd;

  @override
  void initState() {
    super.initState();
    AdMobService.instance.loadInterstitial();
    _bannerAd = AdMobService.instance.createBannerAd(
      onFailed: () => setState(() => _bannerAd = null),
    );
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  void _selectAnswer(int index) {
    if (answered) return;
    final question = widget.level.questions[currentQuestion];
    final isCorrect = index == question.correctIndex;

    setState(() {
      selectedIndex = index;
      answered = true;
      lastAnswerCorrect = isCorrect;
      if (isCorrect) correctAnswers++;
    });

    if (isCorrect) {
      AudioService.instance.playCorrect();
    } else {
      AudioService.instance.playWrong();
    }

    Future.delayed(const Duration(milliseconds: 900), _nextQuestion);
  }

  void _nextQuestion() {
    if (!mounted) return;
    if (currentQuestion < widget.level.questions.length - 1) {
      setState(() {
        currentQuestion++;
        selectedIndex = null;
        answered = false;
      });
    } else {
      _finishLevel();
    }
  }

  void _finishLevel() async {
    final total = widget.level.questions.length;
    final ratio = correctAnswers / total;
    final stars = ratio >= 0.9 ? 3 : (ratio >= 0.6 ? 2 : (ratio > 0 ? 1 : 0));

    await ProgressService.instance.saveStars(widget.category.id, widget.level.levelNumber, stars);
    AudioService.instance.playWin();

    AdMobService.instance.onLevelCompleted(
      onAdClosed: () {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultsScreen(
              category: widget.category,
              level: widget.level,
              stars: stars,
              correctAnswers: correctAnswers,
              totalQuestions: total,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.level.questions[currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.category.nameAr} - مرحلة ${widget.level.levelNumber}'),
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (currentQuestion + 1) / widget.level.questions.length,
            color: widget.category.color,
            backgroundColor: widget.category.color.withOpacity(0.15),
            minHeight: 8,
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(32),
                    decoration: BoxDecoration(
                      color: widget.category.color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Text(
                      question.prompt,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
                    ),
                  )
                      .animate(target: answered ? 1 : 0, key: ValueKey(currentQuestion))
                      .shake(hz: lastAnswerCorrect == false ? 4 : 0, duration: 400.ms)
                      .scale(
                        begin: const Offset(1, 1),
                        end: lastAnswerCorrect == true ? const Offset(1.08, 1.08) : const Offset(1, 1),
                        duration: 300.ms,
                      ),
                  const SizedBox(height: 40),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 16,
                      crossAxisSpacing: 16,
                      childAspectRatio: 2.4,
                    ),
                    itemCount: question.options.length,
                    itemBuilder: (context, index) {
                      final isSelected = selectedIndex == index;
                      final isCorrectOption = index == question.correctIndex;
                      Color bgColor = Colors.white;
                      if (answered && isSelected) {
                        bgColor = isCorrectOption ? Colors.green.shade300 : Colors.red.shade300;
                      } else if (answered && isCorrectOption) {
                        bgColor = Colors.green.shade200;
                      }
                      return ElevatedButton(
                        onPressed: () => _selectAnswer(index),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: bgColor,
                          foregroundColor: Colors.black87,
                          elevation: 3,
                        ),
                        child: Text(
                          question.options[index],
                          style: const TextStyle(fontSize: 22),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          if (_bannerAd != null)
            SizedBox(
              width: _bannerAd!.size.width.toDouble(),
              height: _bannerAd!.size.height.toDouble(),
              child: AdWidget(ad: _bannerAd!),
            ),
        ],
      ),
    );
  }
}
