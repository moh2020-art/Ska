import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../../models/category_model.dart';
import '../../models/level_model.dart';
import '../../services/admob_service.dart';
import '../../services/audio_service.dart';
import '../../services/progress_service.dart';
import '../../widgets/ad_banner_widget.dart';
import '../results_screen.dart';

const _balloonColors = [Color(0xFFFF6B6B), Color(0xFF4D96FF), Color(0xFFFFC107), Color(0xFF6BCB77), Color(0xFF9B5DE5)];

class BalloonPopGameScreen extends StatefulWidget {
  final CategoryModel category;
  final LevelModel level;
  const BalloonPopGameScreen({super.key, required this.category, required this.level});

  @override
  State<BalloonPopGameScreen> createState() => _BalloonPopGameScreenState();
}

class _BalloonPopGameScreenState extends State<BalloonPopGameScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  int currentRound = 0;
  int correctAnswers = 0;
  final Set<int> poppedIndices = {}; // بالونات فُرقعت في هذه الجولة (اختفت بصريًا)
  int? justPoppedCorrectIndex;
  bool roundLocked = false;
  BannerAd? _bannerAd;

  @override
  void initState() {
    super.initState();
    AdMobService.instance.loadInterstitial();
    // كلما زادت الصعوبة، البالونات تتحرك أسرع
    final durationSeconds = max(3, 7 - widget.level.difficulty);
    _controller = AnimationController(vsync: this, duration: Duration(seconds: durationSeconds))..repeat();
    _bannerAd = AdMobService.instance.createBannerAd(onFailed: () => setState(() {}));
  }

  @override
  void dispose() {
    _controller.dispose();
    _bannerAd?.dispose();
    super.dispose();
  }

  void _onBalloonTap(int index, int correctIndex) {
    if (roundLocked || poppedIndices.contains(index)) return;

    final isCorrect = index == correctIndex;
    setState(() {
      poppedIndices.add(index);
      if (isCorrect) justPoppedCorrectIndex = index;
    });

    if (isCorrect) {
      roundLocked = true;
      correctAnswers++;
      AudioService.instance.playCorrect();
      Future.delayed(const Duration(milliseconds: 600), _nextRound);
    } else {
      AudioService.instance.playWrong();
      // البالون الخطأ يختفي فقط، واللعبة تستمر بدون قفل الجولة
      Future.delayed(const Duration(milliseconds: 400), () {
        if (mounted) setState(() => poppedIndices.remove(index));
      });
    }
  }

  void _nextRound() {
    if (!mounted) return;
    if (currentRound < widget.level.questions.length - 1) {
      setState(() {
        currentRound++;
        poppedIndices.clear();
        justPoppedCorrectIndex = null;
        roundLocked = false;
      });
    } else {
      _finishLevel();
    }
  }

  void _finishLevel() async {
    final total = widget.level.questions.length;
    final ratio = correctAnswers / total;
    final stars = ratio >= 0.9 ? 3 : (ratio >= 0.6 ? 2 : (ratio > 0 ? 1 : 0));

    await ProgressService.instance.saveStars(widget.category.id, widget.level.levelNumber, stars);
    AudioService.instance.playWin();

    AdMobService.instance.onLevelCompleted(
      onAdClosed: () {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultsScreen(
              category: widget.category,
              level: widget.level,
              stars: stars,
              correctAnswers: correctAnswers,
              totalQuestions: total,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.level.questions[currentRound];
    final size = MediaQuery.of(context).size;
    final playAreaHeight = size.height * 0.55;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.category.nameAr} - مرحلة ${widget.level.levelNumber}'),
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (currentRound + 1) / widget.level.questions.length,
            color: widget.category.color,
            backgroundColor: widget.category.color.withOpacity(0.15),
            minHeight: 8,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'اضغط على البالون الذي يحمل: ${question.prompt}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: playAreaHeight,
            width: double.infinity,
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                return Stack(
                  children: List.generate(question.options.length, (i) {
                    if (poppedIndices.contains(i) && i != justPoppedCorrectIndex) {
                      return const SizedBox.shrink();
                    }
                    // كل بالون له طور حركة مختلف حتى لا تتحرك معًا بتزامن رتيب
                    final phase = i / question.options.length;
                    final t = (_controller.value + phase) % 1.0;
                    final yFraction = 1.0 - t; // من الأسفل (1) إلى الأعلى (0)
                    final xWave = sin((t * 2 * pi) + i) * 12;
                    final xFraction = (i + 0.5) / question.options.length;

                    final isPoppingCorrect = i == justPoppedCorrectIndex;

                    return Positioned(
                      left: (xFraction * (size.width - 90)) + xWave,
                      top: yFraction * (playAreaHeight - 90),
                      child: GestureDetector(
                        onTap: () => _onBalloonTap(i, question.correctIndex),
                        child: AnimatedScale(
                          scale: isPoppingCorrect ? 1.4 : 1.0,
                          duration: const Duration(milliseconds: 300),
                          child: AnimatedOpacity(
                            opacity: isPoppingCorrect ? 0.0 : 1.0,
                            duration: const Duration(milliseconds: 400),
                            child: Container(
                              width: 78,
                              height: 90,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: _balloonColors[i % _balloonColors.length],
                                borderRadius: BorderRadius.circular(40),
                                boxShadow: [
                                  BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 6, offset: const Offset(0, 4)),
                                ],
                              ),
                              child: Text(
                                question.options[i],
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ),
          if (_bannerAd != null)
            SizedBox(
              width: _bannerAd!.size.width.toDouble(),
              height: _bannerAd!.size.height.toDouble(),
              child: AdWidget(ad: _bannerAd!),
            )
          else
            const AdBannerWidget(),
        ],
      ),
    );
  }
}
