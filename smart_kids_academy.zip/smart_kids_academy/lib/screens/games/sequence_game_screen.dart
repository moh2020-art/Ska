import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/category_model.dart';
import '../../models/level_model.dart';
import '../../services/admob_service.dart';
import '../../services/audio_service.dart';
import '../../services/progress_service.dart';
import '../results_screen.dart';

class SequenceGameScreen extends StatefulWidget {
  final CategoryModel category;
  final LevelModel level;
  const SequenceGameScreen({super.key, required this.category, required this.level});

  @override
  State<SequenceGameScreen> createState() => _SequenceGameScreenState();
}

class _SequenceGameScreenState extends State<SequenceGameScreen> {
  late List<String> shuffledItems;
  late List<String> correctOrder;
  List<String> selectedOrder = [];
  int mistakes = 0;

  @override
  void initState() {
    super.initState();
    AdMobService.instance.loadInterstitial();
    correctOrder = widget.level.sequenceItems;
    shuffledItems = List.from(correctOrder)..shuffle(Random(widget.level.levelNumber * 13));
  }

  void _onItemTap(String item) {
    if (selectedOrder.contains(item)) return;
    final expectedNext = correctOrder[selectedOrder.length];

    if (item == expectedNext) {
      setState(() => selectedOrder.add(item));
      AudioService.instance.playCorrect();
      if (selectedOrder.length == correctOrder.length) {
        Future.delayed(const Duration(milliseconds: 500), _finishLevel);
      }
    } else {
      mistakes++;
      AudioService.instance.playWrong();
    }
  }

  void _finishLevel() async {
    final stars = mistakes == 0 ? 3 : (mistakes <= 2 ? 2 : 1);
    await ProgressService.instance.saveStars(widget.category.id, widget.level.levelNumber, stars);
    AudioService.instance.playWin();

    AdMobService.instance.onLevelCompleted(
      onAdClosed: () {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultsScreen(
              category: widget.category,
              level: widget.level,
              stars: stars,
              correctAnswers: correctOrder.length,
              totalQuestions: correctOrder.length,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.category.nameAr} - مرحلة ${widget.level.levelNumber}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Text('رتّب العناصر بالضغط عليها بالترتيب الصحيح',
                style: TextStyle(fontSize: 16, color: Colors.grey)),
            const SizedBox(height: 16),
            // صف يعرض التقدم الحالي في الترتيب
            Wrap(
              spacing: 8,
              children: selectedOrder
                  .map((item) => Chip(
                        label: Text(item, style: const TextStyle(fontSize: 18)),
                        backgroundColor: widget.category.color.withOpacity(0.2),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 32),
            Wrap(
              spacing: 16,
              runSpacing: 16,
              alignment: WrapAlignment.center,
              children: shuffledItems.map((item) {
                final used = selectedOrder.contains(item);
                return GestureDetector(
                  onTap: used ? null : () => _onItemTap(item),
                  child: Opacity(
                    opacity: used ? 0.3 : 1,
                    child: Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: widget.category.color,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        item,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
