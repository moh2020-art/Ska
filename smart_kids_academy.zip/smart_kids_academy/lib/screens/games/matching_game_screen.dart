import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/category_model.dart';
import '../../models/level_model.dart';
import '../../services/admob_service.dart';
import '../../services/audio_service.dart';
import '../../services/progress_service.dart';
import '../results_screen.dart';

class _CardData {
  final String value;
  bool isFlipped = false;
  bool isMatched = false;
  _CardData(this.value);
}

class MatchingGameScreen extends StatefulWidget {
  final CategoryModel category;
  final LevelModel level;
  const MatchingGameScreen({super.key, required this.category, required this.level});

  @override
  State<MatchingGameScreen> createState() => _MatchingGameScreenState();
}

class _MatchingGameScreenState extends State<MatchingGameScreen> {
  late List<_CardData> cards;
  int? firstIndex;
  bool isBusy = false;
  int wrongAttempts = 0;

  @override
  void initState() {
    super.initState();
    AdMobService.instance.loadInterstitial();
    final items = widget.level.matchingItems;
    cards = [...items, ...items].map((e) => _CardData(e)).toList()
      ..shuffle(Random(widget.level.levelNumber));
  }

  void _onCardTap(int index) {
    if (isBusy || cards[index].isMatched || cards[index].isFlipped) return;

    setState(() => cards[index].isFlipped = true);
    AudioService.instance.playTap();

    if (firstIndex == null) {
      firstIndex = index;
      return;
    }

    isBusy = true;
    final first = cards[firstIndex!];
    final second = cards[index];

    if (first.value == second.value) {
      setState(() {
        first.isMatched = true;
        second.isMatched = true;
        firstIndex = null;
        isBusy = false;
      });
      AudioService.instance.playCorrect();
      if (cards.every((c) => c.isMatched)) {
        Future.delayed(const Duration(milliseconds: 500), _finishLevel);
      }
    } else {
      wrongAttempts++;
      AudioService.instance.playWrong();
      Future.delayed(const Duration(milliseconds: 700), () {
        setState(() {
          first.isFlipped = false;
          second.isFlipped = false;
          firstIndex = null;
          isBusy = false;
        });
      });
    }
  }

  void _finishLevel() async {
    final pairCount = widget.level.matchingItems.length;
    final stars = wrongAttempts == 0 ? 3 : (wrongAttempts <= pairCount ~/ 2 + 1 ? 2 : 1);

    await ProgressService.instance.saveStars(widget.category.id, widget.level.levelNumber, stars);
    AudioService.instance.playWin();

    AdMobService.instance.onLevelCompleted(
      onAdClosed: () {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultsScreen(
              category: widget.category,
              level: widget.level,
              stars: stars,
              correctAnswers: pairCount,
              totalQuestions: pairCount,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final crossAxisCount = cards.length <= 12 ? 4 : 5;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.category.nameAr} - مرحلة ${widget.level.levelNumber}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
          ),
          itemCount: cards.length,
          itemBuilder: (context, index) {
            final card = cards[index];
            final showFace = card.isFlipped || card.isMatched;
            return GestureDetector(
              onTap: () => _onCardTap(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: showFace
                      ? widget.category.color.withOpacity(card.isMatched ? 0.25 : 0.5)
                      : widget.category.color,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: showFace
                    ? Text(
                        card.value,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      )
                    : const Icon(Icons.question_mark_rounded, color: Colors.white, size: 24),
              ),
            );
          },
        ),
      ),
    );
  }
}
