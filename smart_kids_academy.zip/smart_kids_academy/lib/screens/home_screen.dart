import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/category_model.dart';
import '../data/categories_data.dart';
import '../widgets/ad_banner_widget.dart';
import 'age_section_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text('🎓', style: TextStyle(fontSize: 64))
                  .animate(onPlay: (c) => c.repeat(reverse: true))
                  .scale(duration: 1200.ms, begin: const Offset(1, 1), end: const Offset(1.08, 1.08)),
              const SizedBox(height: 12),
              const Text(
                'أكاديمية الطفل الذكي',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                '${CategoriesData.totalLevels}+ مرحلة تعليمية ممتعة',
                style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
              ),
              const SizedBox(height: 40),
              Expanded(
                child: ListView(
                  children: AgeGroup.values.asMap().entries.map((entry) {
                    final index = entry.key;
                    final group = entry.value;
                    return _AgeGroupCard(group: group)
                        .animate()
                        .fadeIn(delay: (150 * index).ms, duration: 400.ms)
                        .slideX(begin: 0.2, end: 0, delay: (150 * index).ms, duration: 400.ms);
                  }).toList(),
                ),
              ),
              const SizedBox(height: 8),
              const AdBannerWidget(),
            ],
          ),
        ),
      ),
    );
  }
}

class _AgeGroupCard extends StatelessWidget {
  final AgeGroup group;
  const _AgeGroupCard({required this.group});

  @override
  Widget build(BuildContext context) {
    final categories = CategoriesData.byAgeGroup(group);
    final levelCount = categories.fold<int>(0, (sum, c) => sum + c.levelCount);

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Material(
        color: group.color,
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => AgeSectionScreen(ageGroup: group)),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(group.icon, color: Colors.white, size: 48),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.nameAr,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${group.ageRange} · $levelCount مرحلة',
                        style: const TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
