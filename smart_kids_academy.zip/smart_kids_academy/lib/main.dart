import 'package:flutter/material.dart';
import 'services/admob_service.dart';
import 'services/progress_service.dart';
import 'screens/home_screen.dart';
import 'utils/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ProgressService.instance.init();
  await AdMobService.initialize();
  runApp(const SmartKidsAcademyApp());
}

class SmartKidsAcademyApp extends StatelessWidget {
  const SmartKidsAcademyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'أكاديمية الطفل الذكي',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      // دعم الاتجاه من اليمين لليسار لكل التطبيق
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      home: const HomeScreen(),
    );
  }
}
