import 'dart:math';
import '../models/category_model.dart';
import '../models/level_model.dart';
import 'item_pools.dart';

/// مولّد المراحل: يأخذ فئة (Category) ويولّد قائمة كاملة من المراحل
/// بشكل حتمي (Deterministic) بحيث يحصل نفس الطفل على نفس المرحلة
/// في كل مرة (باستخدام Random بذرة ثابتة = رقم المرحلة).
///
/// هذا هو ما يسمح للتطبيق أن يحتوي 1000+ مرحلة بدون كتابة كل واحدة يدويًا:
/// كل مرحلة = نفس القالب + بيانات مختلفة يتم اختيارها بذكاء حسب الصعوبة.
class LevelGenerator {
  /// توليد كل مراحل فئة معيّنة
  static List<LevelModel> generateForCategory(CategoryModel category) {
    return List.generate(category.levelCount, (i) {
      final levelNumber = i + 1;
      final difficulty = _difficultyForLevel(levelNumber, category.levelCount);
      return generateSingleLevel(category, levelNumber, difficulty);
    });
  }

  /// توليد مرحلة واحدة فقط (يُستخدم أيضًا لإعادة اللعب / التحميل الجزئي)
  static LevelModel generateSingleLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
  ) {
    final seed = category.id.hashCode ^ (levelNumber * 7919);
    final rng = Random(seed);

    switch (category.gameType) {
      case GameType.quiz:
        return _generateQuizLevel(category, levelNumber, difficulty, rng);
      case GameType.counting:
        return _generateCountingLevel(category, levelNumber, difficulty, rng);
      case GameType.math:
        return _generateMathLevel(category, levelNumber, difficulty, rng);
      case GameType.matching:
        return _generateMatchingLevel(category, levelNumber, difficulty, rng);
      case GameType.sequence:
        return _generateSequenceLevel(category, levelNumber, difficulty, rng);
      case GameType.balloonPop:
        return _generateBalloonPopLevel(category, levelNumber, difficulty, rng);
      case GameType.trueFalse:
        return _generateTrueFalseLevel(category, levelNumber, difficulty, rng);
      case GameType.fastPuzzle:
        return _generateFastPuzzleLevel(category, levelNumber, difficulty, rng);
    }
  }

  /// الصعوبة تتدرج من 1 إلى 5 كلما تقدم الطفل في الفئة (متاحة للاستخدام الخارجي)
  static int difficultyForLevel(int levelNumber, int totalLevels) =>
      _difficultyForLevel(levelNumber, totalLevels);

  static int _difficultyForLevel(int levelNumber, int totalLevels) {
    final ratio = levelNumber / totalLevels;
    if (ratio <= 0.2) return 1;
    if (ratio <= 0.4) return 2;
    if (ratio <= 0.6) return 3;
    if (ratio <= 0.8) return 4;
    return 5;
  }

  // ---------------------------------------------------------------------
  // نوع 1: أسئلة اختيار من متعدد (حروف، ألوان، أشكال، حيوانات، كلمات...)
  // ---------------------------------------------------------------------
  static LevelModel _generateQuizLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    // عدد الأسئلة داخل المرحلة الواحدة يزيد مع الصعوبة (3 -> 6)
    final questionCount = 3 + (difficulty - 1);
    // عدد الخيارات يزيد مع الصعوبة (2 -> 4)
    final optionCount = min(4, 2 + (difficulty ~/ 2));

    final pool = category.itemPool.isNotEmpty
        ? category.itemPool
        : ItemPools.generalKnowledge.map((e) => e['q'] as String).toList();

    // خاص بفئة المعلومات العامة: نستخدم بنك الأسئلة الجاهز مباشرة
    if (category.id == 'general_knowledge') {
      final gk = ItemPools.generalKnowledge;
      final questions = List.generate(questionCount, (i) {
        final item = gk[(levelNumber + i) % gk.length];
        final options = List<String>.from(item['options'] as List);
        return QuestionData(
          prompt: item['q'] as String,
          options: options,
          correctIndex: item['correct'] as int,
        );
      });
      return LevelModel(
        id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
        categoryId: category.id,
        levelNumber: levelNumber,
        difficulty: difficulty,
        gameType: GameType.quiz,
        questions: questions,
      );
    }

    final questions = List.generate(questionCount, (qi) {
      final correctItem = pool[(levelNumber + qi) % pool.length];
      final wrongOptions = <String>{};
      while (wrongOptions.length < optionCount - 1) {
        final candidate = pool[rng.nextInt(pool.length)];
        if (candidate != correctItem) wrongOptions.add(candidate);
      }
      final options = [correctItem, ...wrongOptions]..shuffle(rng);
      return QuestionData(
        prompt: correctItem,
        options: options,
        correctIndex: options.indexOf(correctItem),
      );
    });

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.quiz,
      questions: questions,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 2: العد (اختر الرقم الصحيح لعدد عناصر معروضة)
  // ---------------------------------------------------------------------
  static LevelModel _generateCountingLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    final maxCount = 3 + difficulty * 2; // يزيد أقصى عدد مع الصعوبة
    final questionCount = 3 + (difficulty - 1);

    final questions = List.generate(questionCount, (qi) {
      final correctCount = 1 + rng.nextInt(maxCount);
      final options = <int>{correctCount};
      while (options.length < 4) {
        final delta = rng.nextInt(3) + 1;
        final candidate = rng.nextBool() ? correctCount + delta : max(1, correctCount - delta);
        options.add(candidate);
      }
      final optionsList = options.toList()..shuffle(rng);
      return QuestionData(
        prompt: '🔵' * correctCount, // يمثَّل بصريًا في الواجهة كعناصر متكررة
        options: optionsList.map((e) => e.toString()).toList(),
        correctIndex: optionsList.indexOf(correctCount),
      );
    });

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.counting,
      questions: questions,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 3: رياضيات (جمع وطرح، تصعب تدريجيًا)
  // ---------------------------------------------------------------------
  static LevelModel _generateMathLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    final maxNumber = 5 * difficulty; // نطاق الأرقام يكبر مع الصعوبة
    final questionCount = 4 + difficulty;
    final allowSubtraction = difficulty >= 2;

    final questions = List.generate(questionCount, (qi) {
      final a = 1 + rng.nextInt(maxNumber);
      final b = 1 + rng.nextInt(maxNumber);
      final isAddition = !allowSubtraction || rng.nextBool();
      final int correctAnswer;
      final String prompt;
      if (isAddition) {
        correctAnswer = a + b;
        prompt = '$a + $b = ؟';
      } else {
        final big = max(a, b);
        final small = min(a, b);
        correctAnswer = big - small;
        prompt = '$big - $small = ؟';
      }
      final options = <int>{correctAnswer};
      while (options.length < 4) {
        final delta = 1 + rng.nextInt(4);
        final candidate = rng.nextBool() ? correctAnswer + delta : max(0, correctAnswer - delta);
        options.add(candidate);
      }
      final optionsList = options.toList()..shuffle(rng);
      return QuestionData(
        prompt: prompt,
        options: optionsList.map((e) => e.toString()).toList(),
        correctIndex: optionsList.indexOf(correctAnswer),
      );
    });

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.math,
      questions: questions,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 4: لعبة الذاكرة (مطابقة الأزواج)
  // ---------------------------------------------------------------------
  static LevelModel _generateMatchingLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    // عدد الأزواج يزيد مع الصعوبة: 3 أزواج (سهل) -> 8 أزواج (صعب)
    final pairCount = min(8, 3 + difficulty);
    final pool = List<String>.from(category.itemPool)..shuffle(rng);
    final items = pool.take(pairCount).toList();

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.matching,
      matchingItems: items,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 5: الترتيب (أرقام تصاعديًا أو حروف أبجديًا)
  // ---------------------------------------------------------------------
  static LevelModel _generateSequenceLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    final itemCount = min(8, 3 + difficulty);
    List<String> sequence;

    if (category.itemPool.isNotEmpty) {
      // ترتيب أبجدي: نأخذ مقطعًا متتاليًا من بنك الحروف
      final startMax = max(1, category.itemPool.length - itemCount);
      final start = rng.nextInt(startMax);
      sequence = category.itemPool.sublist(start, start + itemCount);
    } else {
      // ترتيب أرقام تصاعديًا
      final start = 1 + rng.nextInt(20);
      sequence = List.generate(itemCount, (i) => (start + i).toString());
    }

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.sequence,
      sequenceItems: sequence,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 6: فرقعة البالونات (بالونات متحركة تحمل خيارات، اضغط الصحيحة)
  // ---------------------------------------------------------------------
  static LevelModel _generateBalloonPopLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    // عدد الجولات وعدد البالونات في كل جولة يزيدان مع الصعوبة
    final roundCount = 4 + difficulty;
    final balloonCount = min(6, 3 + difficulty ~/ 2);
    final pool = category.itemPool;

    final questions = List.generate(roundCount, (qi) {
      final correctItem = pool[(levelNumber + qi) % pool.length];
      final wrongOptions = <String>{};
      while (wrongOptions.length < balloonCount - 1) {
        final candidate = pool[rng.nextInt(pool.length)];
        if (candidate != correctItem) wrongOptions.add(candidate);
      }
      final options = [correctItem, ...wrongOptions]..shuffle(rng);
      return QuestionData(
        prompt: correctItem,
        options: options,
        correctIndex: options.indexOf(correctItem),
      );
    });

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.balloonPop,
      questions: questions,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 7: صح أو خطأ (عبارة يحكم عليها الطفل)
  // ---------------------------------------------------------------------
  static LevelModel _generateTrueFalseLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    final questionCount = 4 + difficulty;
    final facts = ItemPools.trueFalseFacts;

    final questions = List.generate(questionCount, (qi) {
      final fact = facts[(levelNumber + qi) % facts.length];
      final isTrue = fact['answer'] as bool;
      const options = ['صح', 'خطأ'];
      return QuestionData(
        prompt: fact['statement'] as String,
        options: options,
        correctIndex: isTrue ? 0 : 1,
      );
    });

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.trueFalse,
      questions: questions,
    );
  }

  // ---------------------------------------------------------------------
  // نوع 8: بازل سريع (أعد ترتيب حروف كلمة مبعثرة)
  // ---------------------------------------------------------------------
  static LevelModel _generateFastPuzzleLevel(
    CategoryModel category,
    int levelNumber,
    int difficulty,
    Random rng,
  ) {
    final pool = category.itemPool;
    final word = pool[(levelNumber - 1) % pool.length];
    // نحوّل الكلمة إلى قائمة حروف مبعثرة يعيد الطفل ترتيبها (sequenceItems = الترتيب الصحيح)
    final letters = word.split('');

    return LevelModel(
      id: '${category.id}_${levelNumber.toString().padLeft(3, '0')}',
      categoryId: category.id,
      levelNumber: levelNumber,
      difficulty: difficulty,
      gameType: GameType.fastPuzzle,
      sequenceItems: letters,
    );
  }
}
