import 'category_model.dart';

/// سؤال واحد داخل مرحلة (لأسلوب الاختيار من متعدد)
class QuestionData {
  final String prompt; // نص السؤال أو الرمز المعروض
  final List<String> options; // الخيارات المعروضة
  final int correctIndex; // فهرس الإجابة الصحيحة داخل options

  const QuestionData({
    required this.prompt,
    required this.options,
    required this.correctIndex,
  });
}

/// مرحلة كاملة (قد تحتوي على عدة أسئلة/جولات صغيرة)
class LevelModel {
  final String id; // مثال: arabic_letters_042
  final String categoryId;
  final int levelNumber; // رقم المرحلة داخل الفئة (1..N)
  final int difficulty; // 1 = سهل ... 5 = صعب
  final GameType gameType;
  final List<QuestionData> questions; // للأنواع quiz/counting/math
  final List<String> matchingItems; // لنوع matching (عناصر بدون تكرار، سيتم مضاعفتها)
  final List<String> sequenceItems; // لنوع sequence (الترتيب الصحيح بالفعل)

  const LevelModel({
    required this.id,
    required this.categoryId,
    required this.levelNumber,
    required this.difficulty,
    required this.gameType,
    this.questions = const [],
    this.matchingItems = const [],
    this.sequenceItems = const [],
  });
}
