import 'package:flutter/material.dart';

/// أنواع الألعاب المدعومة في التطبيق
enum GameType {
  quiz, // اختيار من متعدد (حروف/أرقام/ألوان/أشكال/حيوانات...)
  matching, // لعبة الذاكرة (مطابقة الأزواج)
  counting, // عد العناصر واختيار الرقم الصحيح
  sequence, // ترتيب العناصر (تصاعديًا / أبجديًا)
  math, // عمليات حسابية بسيطة (جمع وطرح)
  balloonPop, // فرقعة البالونات: بالونات متحركة، اضغط على الصحيحة
  trueFalse, // صح أو خطأ: عبارة وحكم عليها
  fastPuzzle, // بازل سريع: أعد ترتيب القطع المبعثرة لتكوين الصورة/الكلمة
}

/// الفئة العمرية المستهدفة
enum AgeGroup {
  toddlers, // 2-4 سنوات: البراعم
  kids, // 4-6 سنوات: النجوم
  juniors, // 6-9 سنوات: العباقرة
}

extension AgeGroupInfo on AgeGroup {
  String get nameAr {
    switch (this) {
      case AgeGroup.toddlers:
        return 'البراعم';
      case AgeGroup.kids:
        return 'النجوم';
      case AgeGroup.juniors:
        return 'العباقرة';
    }
  }

  String get ageRange {
    switch (this) {
      case AgeGroup.toddlers:
        return '2-4 سنوات';
      case AgeGroup.kids:
        return '4-6 سنوات';
      case AgeGroup.juniors:
        return '6-9 سنوات';
    }
  }

  Color get color {
    switch (this) {
      case AgeGroup.toddlers:
        return const Color(0xFFFF8A65);
      case AgeGroup.kids:
        return const Color(0xFF4FC3F7);
      case AgeGroup.juniors:
        return const Color(0xFF9575CD);
    }
  }

  IconData get icon {
    switch (this) {
      case AgeGroup.toddlers:
        return Icons.child_care;
      case AgeGroup.kids:
        return Icons.star;
      case AgeGroup.juniors:
        return Icons.emoji_objects;
    }
  }
}

/// نموذج فئة تعليمية (مثال: حروف عربية، ألوان، رياضيات...)
class CategoryModel {
  final String id;
  final String nameAr;
  final IconData icon;
  final Color color;
  final AgeGroup ageGroup;
  final GameType gameType;
  final int levelCount;
  final List<String> itemPool; // مجموعة العناصر الأساسية لهذه الفئة (حروف/كلمات/رموز)

  const CategoryModel({
    required this.id,
    required this.nameAr,
    required this.icon,
    required this.color,
    required this.ageGroup,
    required this.gameType,
    required this.levelCount,
    this.itemPool = const [],
  });
}
