# 🚀 تعليمات نهائية: تصنيع التطبيق الموقّع الجاهز للنشر

هذا المشروع **جاهز 100%**: كل أكواد AdMob الحقيقية مدمجة، ومفتاح التوقيع
(upload-keystore.jks) موجود بالفعل داخل مجلد `signing/`. لم يتبقَّ سوى
تنفيذ 4 أوامر على أي جهاز كمبيوتر (لك، لصديق، أو لأي محل صيانة كمبيوتر/
فريلانسر تدفع له مبلغًا بسيطًا). لا حاجة لأي حساب GitHub أو أي حساب آخر.

## المتطلبات على ذلك الجهاز (تُثبَّت مرة واحدة فقط)
- Flutter SDK: https://docs.flutter.dev/get-started/install
- Android Studio (لتوفير أدوات Android SDK)

## الأوامر (تُنفَّذ داخل مجلد المشروع بعد فك الضغط)

```bash
# 1) توليد مجلدي android/ios الناقصين (لن يمس ملفاتنا الموجودة)
flutter create --platforms=android --org com.smartkids .

# 2) تثبيت الحزم
flutter pub get

# 3) نقل ملفات التوقيع لمكانها الصحيح داخل مجلد android
cp signing/upload-keystore.jks android/app/upload-keystore.jks
cp signing/key.properties android/key.properties
```

ثم افتح `android/app/build.gradle` وأضف قبل `android {`:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
```
وداخل `android { ... }` أضف قبل `buildTypes`:
```gradle
signingConfigs {
    release {
        keyAlias keystoreProperties['keyAlias']
        keyPassword keystoreProperties['keyPassword']
        storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
        storePassword keystoreProperties['storePassword']
    }
}
```
وغيّر داخل `buildTypes { release { ... } }`:
```gradle
buildTypes {
    release {
        signingConfig signingConfigs.release
    }
}
```

وأخيرًا، أضف meta-data الخاص بـ AdMob داخل `android/app/src/main/AndroidManifest.xml` (داخل وسم `<application>`):
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-7099926009548964~7691839052"/>
```

## 4) البناء النهائي (الأمر الوحيد المطلوب فعليًا)

```bash
flutter build appbundle --release
```

الملف الناتج (جاهز للرفع مباشرة على Google Play):
`build/app/outputs/bundle/release/app-release.aab`

أو لتثبيت تجريبي مباشر على هاتف عبر USB بدل الرفع للمتجر:
```bash
flutter build apk --release
```
الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## ⚠️ احتفظ بملفي upload-keystore.jks وkey.properties في مكان آمن دائمًا
إن فقدتهما مستقبلًا، لن تستطيع رفع أي تحديث لنفس التطبيق على Google Play مطلقًا
(ستضطر لنشره كتطبيق جديد بالكامل). لا ترفعهما لأي موقع عام.
